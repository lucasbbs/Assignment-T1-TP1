#ifndef CODIGO_H
#define CODIGO_H

#include <string>

class Codigo
{
private:
  std::string valor;
  std::string gerarCodigo();

public:
  Codigo(int valor);
  ~Codigo();
};

#endif // CODIGO_H